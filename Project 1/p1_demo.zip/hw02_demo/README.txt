This demo is a binary compiled on general.asu and can only be executed there

Run the demo with the given txt files in inputs/ from hw02_starter.zip

If you run into errors like 'Permission Denied', run
	
	chmod 777 encoder

to allow your own user to execute the encoder.


== How to run the demo

e.g. (BEWARE of the '<', miss it and you will run into errors)


	./encoder < common500.txt


^ assuming encoder and common500.txt are in the same directory